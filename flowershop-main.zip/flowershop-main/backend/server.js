const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs-extra');
const path = require('path');

const app3000 = express();
const app3001 = express();

const PORT_USER = 3000;
const PORT_ADMIN = 3001;

// Middleware
app3000.use(cors());
app3000.use(bodyParser.json());
app3000.use(express.static(path.join(__dirname, '../frontend')));

app3001.use(cors());
app3001.use(bodyParser.json());
app3001.use('/admin', express.static(path.join(__dirname, '../admin-panel')));

// Data file paths
const PRODUCTS_FILE = path.join(__dirname, 'data/products.json');
const ORDERS_FILE = path.join(__dirname, 'data/orders.json');
const MESSAGES_FILE = path.join(__dirname, 'data/messages.json');
const USERS_FILE = path.join(__dirname, 'data/users.json');

// Helper to read/write JSON
const readData = async (file) => {
    return await fs.readJson(file);
};

const writeData = async (file, data) => {
    await fs.writeJson(file, data, { spaces: 2 });
};

// --- COMMON APIs (accessible from both or filtered) ---

// Login API
const handleLogin = async (req, res, role) => {
    const { email, password } = req.body;
    const users = await readData(USERS_FILE);
    const user = users.find(u => u.email === email && u.password === password && u.role === role);
    
    if (user) {
        res.json({ success: true, message: 'Login successful', user: { email: user.email, role: user.role } });
    } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
};

app3000.post('/login', (req, res) => handleLogin(req, res, 'user'));
app3001.post('/admin/login', (req, res) => handleLogin(req, res, 'admin'));

// Products API
app3000.get('/products', async (req, res) => {
    const products = await readData(PRODUCTS_FILE);
    res.json(products);
});

app3001.get('/products', async (req, res) => {
    const products = await readData(PRODUCTS_FILE);
    res.json(products);
});

app3001.post('/products', async (req, res) => {
    const products = await readData(PRODUCTS_FILE);
    const newProduct = { id: Date.now(), ...req.body };
    products.push(newProduct);
    await writeData(PRODUCTS_FILE, products);
    res.json({ success: true, product: newProduct });
});

app3001.delete('/product/:id', async (req, res) => {
    const { id } = req.params;
    let products = await readData(PRODUCTS_FILE);
    products = products.filter(p => p.id != id);
    await writeData(PRODUCTS_FILE, products);
    res.json({ success: true });
});

// Orders API
app3000.post('/order', async (req, res) => {
    const orders = await readData(ORDERS_FILE);
    const newOrder = { 
        id: `ORD-${Date.now()}`, 
        ...req.body, 
        status: 'Pending', 
        date: new Date().toLocaleString() 
    };
    orders.push(newOrder);
    await writeData(ORDERS_FILE, orders);
    res.json({ success: true, order: newOrder });
});

app3001.get('/orders', async (req, res) => {
    const orders = await readData(ORDERS_FILE);
    res.json(orders);
});

// User orders specific
app3000.get('/orders/:email', async (req, res) => {
    const { email } = req.params;
    console.log(`[GET] Fetching orders for: ${email}`);
    try {
        const orders = await readData(ORDERS_FILE);
        const userOrders = orders.filter(o => o.customerEmail === email);
        console.log(`Found ${userOrders.length} orders for ${email}`);
        res.json(userOrders);
    } catch (err) {
        console.error('Error reading orders file:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});
app3000.put('/order/:id/status', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    let orders = await readData(ORDERS_FILE);
    const index = orders.findIndex(o => o.id === id);

    if (index !== -1) {
        // Only allow user to cancel if it's currently Pending
        if (status === 'Cancelled' && orders[index].status !== 'Pending') {
            return res.status(400).json({ success: false, message: 'Only pending orders can be cancelled' });
        }
        orders[index].status = status;
        await writeData(ORDERS_FILE, orders);
        res.json({ success: true, order: orders[index] });
    } else {
        res.status(404).json({ success: false, message: 'Order not found' });
    }
});

app3001.put('/order/:id', async (req, res) => {
    const { id } = req.params;
    const { status, total } = req.body;
    let orders = await readData(ORDERS_FILE);
    const index = orders.findIndex(o => o.id === id);
    if (index !== -1) {
        orders[index].status = status || orders[index].status;
        if (total) orders[index].total = total;
        await writeData(ORDERS_FILE, orders);
        res.json({ success: true, order: orders[index] });
    } else {
        res.status(404).json({ success: false, message: 'Order not found' });
    }
});

// Messages API
app3000.post('/messages', async (req, res) => {
    const messages = await readData(MESSAGES_FILE);
    const newMessage = { id: Date.now(), ...req.body, date: new Date().toLocaleString() };
    messages.push(newMessage);
    await writeData(MESSAGES_FILE, messages);
    res.json({ success: true });
});

app3001.get('/messages', async (req, res) => {
    const messages = await readData(MESSAGES_FILE);
    res.json(messages);
});

// Admin Stats
app3001.get('/stats', async (req, res) => {
    const products = await readData(PRODUCTS_FILE);
    const orders = await readData(ORDERS_FILE);
    const messages = await readData(MESSAGES_FILE);
    
    const totalSales = orders
        .filter(o => o.status === 'Delivered')
        .reduce((sum, o) => sum + (parseFloat(o.total) || 0), 0);

    res.json({
        totalProducts: products.length,
        totalOrders: orders.length,
        pendingOrders: orders.filter(o => o.status === 'Pending').length,
        totalMessages: messages.length,
        totalSales: totalSales.toFixed(2)
    });
});

// Redirect root to admin for 3001
app3001.get('/', (req, res) => res.redirect('/admin'));

// Start Servers
app3000.listen(PORT_USER, () => {
    console.log(`\x1b[32m✔ User Website running at http://localhost:${PORT_USER}\x1b[0m`);
});

app3001.listen(PORT_ADMIN, () => {
    console.log(`\x1b[34m✔ Admin Panel running at http://localhost:${PORT_ADMIN}/admin\x1b[0m`);
});
