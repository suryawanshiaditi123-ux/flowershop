document.addEventListener('DOMContentLoaded', () => {
    // --- State ---
    let stats = {};
    let products = [];
    let orders = [];
    let messages = [];
    let currentSection = 'dashboard';
    const API_BASE = 'http://localhost:3001';

    // --- DOM Elements ---
    const adminLoginOverlay = document.getElementById('adminLoginOverlay');
    const adminLoginForm = document.getElementById('adminLoginForm');
    const contentArea = document.getElementById('contentArea');
    const sectionTitle = document.getElementById('sectionTitle');
    const navItems = document.querySelectorAll('.sidebar-nav li');
    const productModal = document.getElementById('productModal');
    const productForm = document.getElementById('productForm');
    const logoutBtn = document.getElementById('adminLogout');
    const closeBtn = document.querySelector('.close');

    // --- Helpers ---
    const showToast = (message) => {
        const toast = document.getElementById('adminToast');
        toast.textContent = message;
        toast.style.display = 'block';
        setTimeout(() => toast.style.display = 'none', 3000);
    };

    const checkAuth = () => {
        const admin = localStorage.getItem('admin');
        if (admin) {
            adminLoginOverlay.style.display = 'none';
            loadSection('dashboard');
        } else {
            adminLoginOverlay.style.display = 'flex';
        }
    };

    const fetchData = async (endpoint) => {
        try {
            const res = await fetch(`${API_BASE}/${endpoint}`);
            return await res.json();
        } catch (err) {
            console.error(`Error fetching ${endpoint}:`, err);
            return null;
        }
    };

    // --- Rendering Sections ---
    const renderDashboard = async () => {
        const data = await fetchData('stats');
        contentArea.innerHTML = `
            <div class="stats-grid">
                <div class="stat-card">
                    <i class="fas fa-shopping-bag"></i>
                    <div>
                        <h3>₹${data.totalSales}</h3>
                        <p>Total Revenue</p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-shopping-cart"></i>
                    <div>
                        <h3>${data.totalOrders}</h3>
                        <p>Total Orders</p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-clock"></i>
                    <div>
                        <h3>${data.pendingOrders}</h3>
                        <p>Pending Orders</p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-envelope"></i>
                    <div>
                        <h3>${data.totalMessages}</h3>
                        <p>Inquiries</p>
                    </div>
                </div>
            </div>
            
            <div class="recent-activity">
                <h2 style="margin-bottom: 1.5rem;">Quick Stats Overview</h2>
                <div style="background: white; padding: 2rem; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.02);">
                    <p style="color: #666;">Total Products Managed: <strong>${data.totalProducts}</strong></p>
                    <p style="color: #666; margin-top: 1rem;">System Status: <span style="color: green; font-weight: 600;">Optimal</span></p>
                </div>
            </div>
        `;
    };

    const renderOrders = async () => {
        const data = await fetchData('orders');
        contentArea.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.reverse().map(order => `
                        <tr>
                            <td>${order.id}</td>
                            <td>${order.customerEmail}</td>
                            <td>${order.items.length} Bouquets</td>
                            <td>₹${order.total}</td>
                            <td><span class="status status-${order.status.toLowerCase()}">${order.status}</span></td>
                            <td class="action-btns">
                                <button class="btn-small" onclick='window.showEditOrderModal(${JSON.stringify(order)})'>Edit</button>
                                <button class="btn-small btn-delete" onclick="window.archiveOrder('${order.id}')">Archive</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    };

    const renderProducts = async () => {
        const data = await fetchData('products');
        contentArea.innerHTML = `
            <div class="admin-actions">
                <button class="btn-primary" onclick="window.showAddProductModal()">+ Add New Flower</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.reverse().map(prod => `
                        <tr>
                            <td><img src="${prod.image}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;"></td>
                            <td>${prod.name}</td>
                            <td>${prod.category}</td>
                            <td>₹${prod.price}</td>
                            <td class="action-btns">
                                <button class="btn-small btn-delete" onclick="deleteProduct(${prod.id})">Delete</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    };

    const renderMessages = async () => {
        const data = await fetchData('messages');
        contentArea.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Sender</th>
                        <th>Email</th>
                        <th>Message</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.reverse().map(msg => `
                        <tr>
                            <td>${msg.date.split(',')[0]}</td>
                            <td>${msg.name}</td>
                            <td>${msg.email}</td>
                            <td>${msg.message.substring(0, 50)}...</td>
                            <td class="action-btns">
                                <button class="btn-small" onclick="alert('${msg.message}')">View Full</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    };

    const loadSection = (section) => {
        currentSection = section;
        sectionTitle.textContent = section.charAt(0).toUpperCase() + section.slice(1);
        
        navItems.forEach(item => {
            item.classList.remove('active');
            if (item.dataset.section === section) item.classList.add('active');
        });

        if (section === 'dashboard') renderDashboard();
        else if (section === 'orders') renderOrders();
        else if (section === 'products') renderProducts();
        else if (section === 'messages') renderMessages();
    };

    // --- Actions ---
    window.updateOrderStatus = async (id, status) => {
        try {
            await fetch(`${API_BASE}/order/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status })
            });
            showToast('Order status updated');
            renderOrders();
        } catch (err) {
            showToast('Update failed');
        }
    };

    window.deleteProduct = async (id) => {
        if (!confirm('Are you sure you want to delete this product?')) return;
        try {
            await fetch(`${API_BASE}/product/${id}`, { method: 'DELETE' });
            showToast('Product deleted');
            renderProducts();
        } catch (err) {
            showToast('Delete failed');
        }
    };

    window.showAddProductModal = () => {
        productModal.style.display = 'flex';
    };

    window.showEditOrderModal = (order) => {
        document.getElementById('editOrderId').value = order.id;
        document.getElementById('editOrderStatus').value = order.status;
        document.getElementById('editOrderTotal').value = order.total;
        document.getElementById('orderModal').style.display = 'flex';
    };

    window.archiveOrder = (id) => {
        if (confirm('Archive this order?')) {
            showToast('Order archived');
            renderOrders();
        }
    };

    // --- Listeners ---
    adminLoginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('adminEmail').value;
        const password = document.getElementById('adminPassword').value;

        try {
            const res = await fetch(`${API_BASE}/admin/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();

            if (data.success) {
                localStorage.setItem('admin', JSON.stringify(data.user));
                adminLoginOverlay.style.display = 'none';
                loadSection('dashboard');
                showToast('Welcome, Administrator');
            } else {
                showToast(data.message);
            }
        } catch (err) {
            showToast('Login error');
        }
    });

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            loadSection(item.dataset.section);
        });
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('admin');
        adminLoginOverlay.style.display = 'flex';
    });

    productForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newProd = {
            name: document.getElementById('prodName').value,
            price: parseFloat(document.getElementById('prodPrice').value),
            image: document.getElementById('prodImage').value,
            category: document.getElementById('prodCategory').value,
            rating: 5
        };

        try {
            await fetch(`${API_BASE}/products`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newProd)
            });
            showToast('Product added successfully');
            productModal.style.display = 'none';
            productForm.reset();
            renderProducts();
        } catch (err) {
            showToast('Error adding product');
        }
    });

    closeBtn.addEventListener('click', () => {
        productModal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === productModal) productModal.style.display = 'none';
        if (e.target === document.getElementById('orderModal')) document.getElementById('orderModal').style.display = 'none';
    });

    document.getElementById('orderEditForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('editOrderId').value;
        const status = document.getElementById('editOrderStatus').value;
        const total = document.getElementById('editOrderTotal').value;

        try {
            await fetch(`${API_BASE}/order/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status, total })
            });
            showToast('Order updated successfully');
            document.getElementById('orderModal').style.display = 'none';
            renderOrders();
        } catch (err) {
            showToast('Update failed');
        }
    });

    // --- Init ---
    checkAuth();
});
