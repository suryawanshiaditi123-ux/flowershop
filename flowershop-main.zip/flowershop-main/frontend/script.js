document.addEventListener('DOMContentLoaded', () => {
    // Initialize AOS
    AOS.init({
        duration: 800,
        offset: 100,
        once: true
    });

    // --- State Management ---
    let products = [];
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let user = JSON.parse(localStorage.getItem('user')) || null;

    // --- DOM Elements ---
    const productList = document.getElementById('productList');
    const cartToggle = document.getElementById('cartToggle');
    const loginToggle = document.getElementById('loginToggle');
    const cartModal = document.getElementById('cartModal');
    const loginModal = document.getElementById('loginModal');
    const closeBtns = document.querySelectorAll('.close');
    const cartItemsContainer = document.getElementById('cartItems');
    const cartTotalValue = document.getElementById('cartTotalValue');
    const checkoutBtn = document.getElementById('checkoutBtn');
    const loginForm = document.getElementById('loginForm');
    const contactForm = document.getElementById('contactForm');
    const cartCount = document.querySelector('.cart-count');
    const loader = document.getElementById('loader');
    const autoFillBtn = document.getElementById('autoFillBtn');
    const ordersToggle = document.getElementById('ordersToggle');
    const ordersModal = document.getElementById('ordersModal');
    const userOrdersList = document.getElementById('userOrdersList');

    // --- Helpers ---
    const showToast = (message) => {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 3000);
    };

    const updateCartCount = () => {
        cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0);
    };

    const updateAuthUI = () => {
        if (user) {
            ordersToggle.style.display = 'flex';
            loginToggle.innerHTML = '<i class="fas fa-sign-out-alt"></i>';
        } else {
            ordersToggle.style.display = 'none';
            loginToggle.innerHTML = '<i class="fas fa-user"></i>';
        }
    };

    // --- Fetch Data ---
    const fetchProducts = async () => {
        try {
            const res = await fetch('/products');
            products = await res.json();
            renderProducts();
        } catch (err) {
            console.error('Error fetching products:', err);
            showToast('Failed to load products');
        }
    };

    // --- Render Logic ---
    const renderProducts = () => {
        if (!productList) return;
        productList.innerHTML = products.map(product => `
            <div class="product-card" data-aos="fade-up">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}">
                    <span class="badge">Popular</span>
                </div>
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <div class="rating">
                        ${'★'.repeat(product.rating)}${'☆'.repeat(5 - product.rating)}
                    </div>
                    <span class="price">₹${product.price}</span>
                    <div class="product-actions">
                        <button class="btn btn-primary" onclick="addToCart(${product.id})">Add to Cart</button>
                        <button class="btn btn-outline" onclick="buyNow(${product.id})">Buy Now</button>
                    </div>
                </div>
            </div>
        `).join('');
    };

    const renderCart = () => {
        if (!cartItemsContainer) return;
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p style="text-align:center; padding: 2rem;">Your bag is empty.</p>';
            cartTotalValue.textContent = '$0.00';
            return;
        }

        cartItemsContainer.innerHTML = cart.map((item, index) => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-info">
                    <h4>${item.name}</h4>
                    <p>₹${item.price} x ${item.quantity}</p>
                </div>
                <button onclick="removeFromCart(${index})" style="background:none; border:none; cursor:pointer;"><i class="fas fa-trash-alt" style="color:#777"></i></button>
            </div>
        `).join('');

        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        cartTotalValue.textContent = `₹${total}`;
    };

    const fetchUserOrders = async () => {
        if (!user) return;
        userOrdersList.innerHTML = '<div style="text-align:center; padding: 2rem;"><i class="fas fa-spinner fa-spin"></i> Loading your orders...</div>';
        try {
            const res = await fetch(`/orders/${user.email}`);
            if (!res.ok) throw new Error('Failed to fetch');
            const orders = await res.json();
            renderUserOrders(orders);
        } catch (err) {
            console.error('Error fetching orders:', err);
            userOrdersList.innerHTML = '<p style="text-align:center; padding: 2rem; color: #ff4d4d;">Could not load orders. Please try again.</p>';
        }
    };

    const renderUserOrders = (orders) => {
        if (!userOrdersList) return;
        if (orders.length === 0) {
            userOrdersList.innerHTML = '<p style="text-align:center; padding: 2rem;">No orders found.</p>';
            return;
        }

        const getStatusIndex = (status) => {
            const statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
            return statuses.indexOf(status);
        };

        userOrdersList.innerHTML = [...orders].reverse().map(order => {
            const sIdx = getStatusIndex(order.status);
            const isCancelled = order.status === 'Cancelled';
            const orderDate = order.date ? (order.date.includes(',') ? order.date.split(',')[0] : order.date) : 'Recently';
            
            return `
                <div class="user-order-item ${isCancelled ? 'cancelled-order' : ''}">
                    <div class="order-meta">
                        <div>
                            <span class="order-id">#${order.id}</span>
                            <span class="order-date" style="margin-left: 10px;">• ${orderDate}</span>
                        </div>
                        <span class="status-badge status-${order.status.toLowerCase()}">${order.status}</span>
                    </div>
                    <div class="order-items-list">
                        ${order.items.map(it => `
                            <div class="mini-item">
                                <img src="${it.image}" alt="${it.name}">
                                <div class="mini-item-info">
                                    <span class="name">${it.name}</span>
                                    <span class="qty">x${it.quantity}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    
                    ${!isCancelled ? `
                    <div class="tracking-stepper">
                        <div class="step ${sIdx >= 0 ? 'active' : ''}">
                            <div class="step-icon"><i class="fas fa-receipt"></i></div>
                            <span>Ordered</span>
                        </div>
                        <div class="step-line ${sIdx >= 1 ? 'active' : ''}"></div>
                        <div class="step ${sIdx >= 1 ? 'active' : ''}">
                            <div class="step-icon"><i class="fas ${sIdx === 1 ? 'fa-cog fa-spin' : 'fa-box-open'}"></i></div>
                            <span>Process</span>
                        </div>
                        <div class="step-line ${sIdx >= 2 ? 'active' : ''}"></div>
                        <div class="step ${sIdx >= 2 ? 'active' : ''}">
                            <div class="step-icon"><i class="fas fa-truck"></i></div>
                            <span>Shipped</span>
                        </div>
                        <div class="step-line ${sIdx >= 3 ? 'active' : ''}"></div>
                        <div class="step ${sIdx >= 3 ? 'active' : ''}">
                            <div class="step-icon"><i class="fas fa-check-double"></i></div>
                            <span>Arrived</span>
                        </div>
                    </div>
                    ` : `
                    <div class="cancelled-msg">
                        <i class="fas fa-times-circle"></i> This order was cancelled
                    </div>
                    `}

                    <div class="order-footer">
                        <div class="order-total">Total: <span>₹${order.total}</span></div>
                        <div class="order-actions">
                            ${order.status === 'Pending' ? `
                                <button class="btn-cancel" onclick="cancelOrder('${order.id}')">Cancel Order</button>
                            ` : ''}
                            <button class="btn-reorder" onclick='reorderItems(${JSON.stringify(order.items)})'>
                                <i class="fas fa-redo"></i> Buy Again
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    };

    window.reorderItems = (items) => {
        items.forEach(item => {
            const product = products.find(p => p.id === item.id);
            if (product) addToCart(product.id);
        });
        ordersModal.style.display = 'none';
        cartModal.style.display = 'flex';
        renderCart();
        showToast('Items added to bag!');
    };

    window.cancelOrder = async (orderId) => {
        if (!confirm('Are you sure you want to cancel this order?')) return;
        try {
            const res = await fetch(`/order/${orderId}/status`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'Cancelled' })
            });
            if (res.ok) {
                showToast('Order cancelled successfully');
                fetchUserOrders();
            }
        } catch (err) {
            showToast('Failed to cancel order');
        }
    };

    // --- Cart Actions ---
    window.addToCart = (productId) => {
        const product = products.find(p => p.id === productId);
        const existingItem = cart.find(item => item.id === productId);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }

        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
        showToast('Added to bag!');
    };

    window.buyNow = (productId) => {
        addToCart(productId);
        cartModal.style.display = 'flex';
        renderCart();
    };

    window.removeFromCart = (index) => {
        cart.splice(index, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
        renderCart();
    };

    // --- Event Listeners ---
    cartToggle.addEventListener('click', () => {
        cartModal.style.display = 'flex';
        renderCart();
    });

    loginToggle.addEventListener('click', () => {
        if (user) {
            if (confirm(`Logged in as ${user.email}. Logout?`)) {
                localStorage.removeItem('user');
                user = null;
                updateAuthUI();
                showToast('Logged out');
            }
        } else {
            loginModal.style.display = 'flex';
        }
    });

    ordersToggle.addEventListener('click', () => {
        ordersModal.style.display = 'flex';
        fetchUserOrders();
    });

    closeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            cartModal.style.display = 'none';
            loginModal.style.display = 'none';
            ordersModal.style.display = 'none';
        });
    });

    window.addEventListener('click', (e) => {
        if (e.target === cartModal) cartModal.style.display = 'none';
        if (e.target === loginModal) loginModal.style.display = 'none';
        if (e.target === ordersModal) ordersModal.style.display = 'none';
    });

    // Login Handle
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        try {
            const res = await fetch('/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();

            if (data.success) {
                user = data.user;
                localStorage.setItem('user', JSON.stringify(user));
                loginModal.style.display = 'none';
                updateAuthUI();
                showToast('Welcome back, ' + user.email);
            } else {
                showToast(data.message);
            }
        } catch (err) {
            showToast('Login failed');
        }
    });

    // Auto fill for demo
    if (autoFillBtn) {
        autoFillBtn.addEventListener('click', () => {
            document.getElementById('loginEmail').value = 'urza@user.com';
            document.getElementById('loginPassword').value = '1234';
            showToast('Demo credentials filled!');
        });
    }

    // Contact Handle
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        try {
            await fetch('/messages', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, message })
            });
            showToast('Message sent! We will get back to you soon.');
            contactForm.reset();
        } catch (err) {
            showToast('Error sending message');
        }
    });

    // Checkout Handle
    checkoutBtn.addEventListener('click', async () => {
        if (!user) {
            showToast('Please login to place an order');
            loginModal.style.display = 'flex';
            return;
        }

        if (cart.length === 0) return;

        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const orderData = {
            customerEmail: user.email,
            items: cart,
            total: total.toFixed(2)
        };

        try {
            const res = await fetch('/order', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });
            const data = await res.json();

            if (data.success) {
                showToast('Order placed successfully!');
                cart = [];
                localStorage.setItem('cart', JSON.stringify(cart));
                updateCartCount();
                cartModal.style.display = 'none';
                
                // Automatically show orders to user
                setTimeout(() => {
                    ordersModal.style.display = 'flex';
                    fetchUserOrders();
                }, 1000);
            }
        } catch (err) {
            showToast('Checkout failed. Try again.');
        }
    });

    // --- Init ---
    fetchProducts();
    updateCartCount();
    updateAuthUI();

    // Hide Loader
    window.addEventListener('load', () => {
        setTimeout(() => {
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.display = 'none';
            }, 500);
        }, 1500);
    });
});
